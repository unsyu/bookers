class BooksController < ApplicationController
  # def new
    # @book = Book.new
  # end
  
  def create
    @book = Book.new(book_params)
    if @book.save
    # なぜ　@　が消えたのか？
    # @　をつけるのはviewに引き渡して表示する必要があるときだけ
    # viewに表示するのはすでにdef newの方で完了しているから
    # こっちはアクションが実行されるだけでよいから　@　を付けないと思う
    
    # @　をつけるのかつけないのかをよく確認する必要がある　
    # <解釈1>
    # タイトルもボディー部分のデータも入力した状態で新規投稿をする場合は
    # createアクションの内容はviewに表示する必要がないから@をつけなくてよい
    
    # ＊（@がついていないからと言ってcreateアクションの内容が行われない訳ではない
    # ただview側に情報がいかなくなるので画面に表示されなくなるだけ）
    
    # しかし、データが入力されていない場合は
    # データが入力されていないということをview側に表示してあげないと
    # view側は表示されていないものはデータがないと勘違いしてしまうので
    # データが入力されていないということをview側に表示できるように
    # @をつける必要がある
    
    # <解釈2>
    # book = Book.new（新規投稿欄）に何かしら値を入力した場合は
    
    # index（一覧表示）画面では新しい空の新規投稿欄と
    # 新規投稿欄に入力した内容をそのまま表示すれば良いから
    # コントローラーのindexは
    # @books = Book.all
    # @book = Book.new
    # というように　@　が付く
    # すでにコントローラーのindex部分で、新規投稿欄に入力した値をview側に送って
    # view側で、新規投稿欄に入力した値を表示できているので
    # わざわざコントローラーのcreate部分に　@　をつける必要がない
    # （別に　@　をつけてもcreateは入力された値をデータとして
    # データベースに保存する機能しかないため、view側に送ったところでそれを
    # 表示できないし表示するviewも無いから問題はない）
    
    
    # しかし！book = Book.new（新規投稿欄）に何も値が入力されていない場合は
    
    # 新規投稿欄に値が何も入力されていないので、値を受け取ることもできないし、
    # コントローラーのindex（一覧表示）で　@　をつけたところで
    # view側に値を送ることも表示することもできない
    # そこで、バリデーション設定（今回の場合、 作成されたviewモデルの　book.rb　に
    # validates :title, presence: true
    # validates :body, presence: true
    # という記述）をすると、validatesで対象とする項目を指定して
    # 入力されたデータのpresence（存在）をチェックして、　true　と記述すると
    # データが存在しなければならないという条件になる
    # そのうえで、コントローラーのcreateの内の記述に　@　をつけて
    # view側にcreate内のデータを送って表示できるようにすると
    # コントローラーのcreateには
    # 新規投稿欄に入力された値をデータとしてデータベースに保存する機能があるので
    # 今回のように新規投稿欄に入力された値が何も無いと、ここで初めて
    # 「データベースに保存するデータがありません」というエラー内容のデータが出来上がる
    # そのため、コントローラーのindexでは何をしてもviewに表示ができないから
    # createに　@　をつけてエラー内容をview側に送って表示できるようにする必要がある
    
    
    # book = Book.new（新規投稿欄の機能）は
    # 新規投稿欄に値を入力して、一時的に入力された値を保持する（受け止める）ことから
    # 'Create Book'　ボタンを押す直前までを担っている
    # createは　'Create Book'　ボタンを押した瞬間から
    # 入力された値をデータとしてデータベースに保存するまでまでを担っている
    # だから、バリデーションをした状態ではindexでエラーは感知できず
    # createで初めてエラーとして感知して、そのデータをview側に送ることで表示できる
    
    #エラー内容を表示することは利用者がエラーを修正しやすくなるという利点がある
    #もしエラー内容が表示されず、破棄されてしまったらまた最初から全ての情報を
    # 入力し直す手間がかかってしまう。たった一つの記入漏れでエラーが起こり
    # 入力した内容が破棄されてしまったら、たまったもんじゃない
    
      flash[:notice] = 'Book was successfully created.'
      redirect_to book_path(@book.id)
    else
      @books= Book.all
      # 「空欄によるエラー」のデータを持っているのがこいつ
      # こいつを指定しておかないと
      # データがないことになるので（each.doのメソッドが働きませんという）
      # プログラム全体のエラーが起きてしまう
      render :index
      # renderの移行先はhtmlのファイル名でok
    end
    # リンクをどう貼ったらよいのか？
    # ルーティングエラー画面のhelperを参考にする
    # そもそもview(htmlファイル)のあるurlじゃなきゃ表示できない
    # top_path だったらただTopページを表示するだけだから
    # helperをそのまま使えるけど、詳細画面(show)などの入力された値によって
    # urlが変わるものはidまで記述しないと機能しない
  end
  
  def index
    @books = Book.all
    # この　all　は新規投稿欄に入力された値をすべて受け取る機能がある
    
    @book = Book.new
    # ここにnewの記述を持ってきちゃえば、indexページに投稿・一覧表示機能を反映できる！
    
    # ここの　newアクション　は空の新規投稿欄をその都度作る機能と
    # 入力された値を受け取る機能がある
    # もし、これがないと新規投稿欄が更新されず、
    # 新規投稿欄に一度入力した値がずっとそこに残ったままになってしまう
    # そのうえ、入力した値を受け取ってもらえなくなるから
    # それ以降の動作が行えなくなるのでプログラム全体のエラーになる
  end
  
  def show
    @book = Book.find(params[:id])
  end
  
  def edit
    @book = Book.find(params[:id])
  end
  
  def update
    @book = Book.find(params[:id])
    if @book.update(book_params)
    # なぜ　@　が消えたのか？
    # @　をつけるのはviewに引き渡して表示する必要があるときだけ
    # viewに表示するのはすでにdef editの方で完了しているから
    # こっちはアクションが実行されるだけでよいから　@　を付けない
      flash[:notice] = 'Book was successfully updated.'
      redirect_to book_path(@book.id)
    else
      @books= Book.all
      render :edit
    end
  end
  
  def destroy
    book = Book.find(params[:id])
    book.destroy
    flash[:notice] = 'Book was successfully destroyed.'
    redirect_to books_path
  end
  
  private
  def book_params
    params.require(:book).permit(:title, :body)
    # ユーザーが入力した値
  end
end
